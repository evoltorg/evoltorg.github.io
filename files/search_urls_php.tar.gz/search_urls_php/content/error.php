<h2>Error</h2>

<p>Looks like you passed it some variables that didn't resolve to a page. Shame on you!</p>

<p>As a punishment you can get to see the full array you generated, thanks to the wonders of the PHP <em>print_r</em> function.</p>

<h2>$myarray contains:</h2>
<p><? 
global $myarray;
print_r($myarray); 
?></p>
