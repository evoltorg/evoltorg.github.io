<h2>Loud CD's</h2>

<ul>
<li>God Machine - One Last Laugh In A Place Of Dying</li>
<li>Manic Street Preachers - Generation Terrorists</li>
<li>The Clash - London Calling</li>
<li>Pixies - Death To The Pixies</li>
<li>At The Drive In - Relationship Of Command</li>
</ul>
